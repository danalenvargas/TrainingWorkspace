package com.ibm.training;

public class Dispatcher implements Runnable {
	Service service;
	
	public Dispatcher() {
		// TODO Auto-generated constructor stub
	}
	
	public Dispatcher(Service service) {
		this.service = service;
	}

	@Override
	public void run(){
		while(true) {
			try {
				Thread.sleep(2000);
				Product[] productArray = service.reviewProducts(EnumProdType.PERISHABLE);
				for(int i=0; i<productArray.length; i++) {
					Perishable peri = (Perishable) productArray[i];
					if(peri != null && peri.getExpiresIn() < 1) {
						throw new ExpiredProductException("Dispatcher found an expired product: " + peri.getName());
					}
				}
			} catch (ExpiredProductException e) {
				System.out.println(e.getMessage());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
	}
}
