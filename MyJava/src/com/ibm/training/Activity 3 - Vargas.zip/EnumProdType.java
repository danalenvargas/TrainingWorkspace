package com.ibm.training;

public enum EnumProdType {
	PERISHABLE, NONPERISHABLE;
}
